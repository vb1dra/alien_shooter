from random import randint
from pygame import *

win_X = 1080
win_Y = 720

roomsSprGr = sprite.Group()
buttonsGr = sprite.Group()

class GameSprite(sprite.Sprite):
    def __init__(self, picture, posX, posY, speed, rX, rY):
        super().__init__()
        self.image = transform.scale(image.load(picture),(rX,rY))
        self.speed = speed
        self.rect = self.image.get_rect()
        self.rect.x = posX
        self.rect.y = posY
        self.rX = rX
        self.rY = rY
        self.picture = picture
    def reset(self,png_detecter):
        window.blit(self.image, (self.rect.x, self.rect.y))
        if self.picture == png_detecter:
            self.rect.x = mouse_pos[0]
            self.rect.y = mouse_pos[1]
        
class Player(GameSprite):
    def update(self, speed):
        if keys_pressed[K_a]:
            self.rect.x += speed
        if keys_pressed[K_d]:
            self.rect.x -= speed
        if keys_pressed[K_s]:
            self.rect.y -= speed
        if keys_pressed[K_w]:
            self.rect.y += speed

class GameRoom(sprite.Sprite):
    def __init__(self, picture, posX, posY, lootCount, enemyCount, xr, yr):
        super().__init__()
        self.image = transform.scale(image.load(picture),(xr,yr))
        self.rect = self.image.get_rect()
        self.rect.x = posX
        self.rect.y = posY
    def update(self, speed):
        if keys_pressed[K_a]:
            self.rect.x += speed
        if keys_pressed[K_d]:
            self.rect.x -= speed
        if keys_pressed[K_s]:
            self.rect.y -= speed
        if keys_pressed[K_w]:
            self.rect.y += speed

class ButtonClass(sprite.Sprite):
    def __init__(self, picture, posX, posY, rX, rY,buttonFunc):
        super().__init__()
        self.image = transform.scale(image.load(picture),(rX,rY))
        self.rect = self.image.get_rect()
        self.rect.x = posX
        self.rect.y = posY
        self.rX = rX
        self.rY = rY
        self.picture = picture
        self.buttonFunc = buttonFunc
    def update(self):
        global playButtint
        global world_size
        if (self.rect.x <= mouse_pos[0] and 
                                        self.rect.x+self.rX >= mouse_pos[0] and 
                                        self.rect.y <= mouse_pos[1] and 
                                        self.rect.y+self.rY >= mouse_pos[1]):
            self.image = transform.scale(image.load(str( self.picture[0:self.picture.find('_')+1] + 'on.png')),(self.rX,self.rY))
            if mouse_down_bool:
                if self.buttonFunc == 'playButtint': playButtint = True
                else: playButtint = False  
                if self.buttonFunc == 'world_sizeUp' and world_size < 16: world_size += 1
                if self.buttonFunc == 'world_sizeDown' and world_size > 4: world_size -= 1
            else:
                self.buttint = False
        else:
            self.image = transform.scale(image.load(str( self.picture[0:self.picture.find('_')+1] + 'off.png')),(self.rX,self.rY))
            
######
def roomGenerator(help_integer):
    rooms = []
    seed = str(randint(0,1))
    for i in range(world_size**2-1):
        seed = seed+str(randint(0,1))
    b = 1
    for b in range(world_size+1):
        room = seed[world_size*(b-1) : world_size*b]
        rooms.append(room)
        print(rooms[b])

    b = 1
    while b <= world_size:
        for i in range(len(rooms[b])):
            RoomConHelp = 0
            if rooms[b][i] == '0':
                try:
                    if rooms[b][i-1] == '1' and i != 0: RoomConHelp += 1
                except: None
                try:
                    if rooms[b][i+1] == '1': RoomConHelp += 1
                except: None
                try:
                    if rooms[b-1][i] == '1': RoomConHelp += 1
                except:None
                try:
                    if rooms[b+1][i] == '1': RoomConHelp += 1
                except: None
                #print(RoomConHelp)
                if RoomConHelp == 2 or RoomConHelp == 3:
                    c = str(rooms[b][0:i]) + '2' + str(rooms[b][i+1:len(rooms[b])])
                    rooms[b] = c
        b += 1
    b = 1
    while b <= world_size:
        for i in range(len(rooms[b])):
            RoomConHelp = 0
            if rooms[b][i] == '1':
                try:
                    if rooms[b][i-1] == '1' and i != 0: RoomConHelp += 1
                except: None
                try:
                    if rooms[b][i+1] == '1': RoomConHelp += 1
                except: None
                try:
                    if rooms[b-1][i] == '1': RoomConHelp += 1
                except:None
                try:
                    if rooms[b+1][i] == '1': RoomConHelp += 1
                except: None
                #print(RoomConHelp)
                if RoomConHelp == 4 or RoomConHelp == 3:
                    c = str(rooms[b][0:i]) + '0' + str(rooms[b][i+1:len(rooms[b])])
                    rooms[b] = c
        b += 1
    b = 1
    while b <= world_size:
        for i in range(len(rooms[b])):
            RoomConHelp = 0
            if rooms[b][i] == '2':
                try:
                    if rooms[b][i-1] == '1' and i != 0: RoomConHelp += 1
                except: None
                try:
                    if rooms[b][i+1] == '1': RoomConHelp += 1
                except: None
                try:
                    if rooms[b-1][i] == '1': RoomConHelp += 1
                except:None
                try:
                    if rooms[b+1][i] == '1': RoomConHelp += 1
                except: None
                #print(RoomConHelp)
                if RoomConHelp == 1 or RoomConHelp == 4:
                    c = str(rooms[b][0:i]) + '0' + str(rooms[b][i+1:len(rooms[b])])
                    rooms[b] = c
        b += 1
        #print('\n'+rooms[b])


    for b in range(world_size+1):
        print(rooms[b])        

    startFound = 0
    b = 1
    while b <= world_size:
        for i in range(len(rooms[b])):
            RoomConHelp = 0
            RoomConHelp_2 = 0
            #print(rooms[b][i])
            if rooms[b][i] == '2':
                #rooms = str(rooms[b][i-1])+'2'+str(rooms[b][i+1])
                if i != 0:
                    try:
                        if rooms[b][i-1] == '1': 
                            RoomConHelp_2 += 1
                            RoomConHelp += 1
                    except: None
                try:
                    if rooms[b][i+1] == '1': 
                        RoomConHelp_2 += 1
                        RoomConHelp += 100
                except: None
                try:
                    if rooms[b-1][i] == '1': 
                        RoomConHelp_2 += 1
                        RoomConHelp += 10
                except:None
                try:
                    if rooms[b+1][i] == '1': 
                        RoomConHelp_2 += 1
                        RoomConHelp += 1000
                except: None
            elif rooms[b][i] == '1':
                if i != 0:
                    try:
                        if rooms[b][i-1] == '1' or rooms[b][i-1] == '2': 
                            RoomConHelp += 1
                    except:None
                try:
                    if rooms[b][i+1] == '1' or rooms[b][i+1] == '2': 
                        RoomConHelp += 100
                except: None
                try:
                    if rooms[b-1][i] == '1' or rooms[b-1][i] == '2': 
                        RoomConHelp += 10
                except: None
                try:
                    if rooms[b+1][i] == '1' or rooms[b+1][i] == '2': 
                        RoomConHelp += 1000
                except: None

            if rooms[b][i] == '1' and startFound == 0:
                startFound = 1
                startX = b
                startY = i 
            if rooms[b][i] != 0:
                if RoomConHelp != 0 and rooms[b][i] == '1':
                    roomX = win_Y*i
                    roomY = win_Y*(b-1)
                    room_done = GameRoom(('room_'+str(RoomConHelp)+'.png'), int(roomX/help_integer), int(roomY/help_integer) ,randint(0,5) ,randint(0,5), int(win_Y/help_integer), int(win_Y/help_integer))
                    roomsSprGr.add(room_done)
                if RoomConHelp != 0 and rooms[b][i] == '2' and RoomConHelp_2 == 2 or RoomConHelp_2 == 3:
                    roomX = win_Y*i
                    roomY = win_Y*(b-1)
                    room_done = GameRoom(('corridor_'+str(RoomConHelp)+'.png'), int(roomX/help_integer), int(roomY/help_integer) ,0 ,0 , int(win_Y/help_integer), int(win_Y/help_integer))
                    roomsSprGr.add(room_done)
        b += 1
    for b in range(world_size+1):
        print(rooms[b])

world_size = int(input('Границы мира:'))
help_intgre = int(input('Кол-во комнат на экране (просто для теста):'))
roomGenerator(help_intgre)

window = display.set_mode((win_X,win_Y),RESIZABLE)
display.set_caption('RogeTale')
background = transform.scale(image.load('menu.png'),(win_X,win_Y))

playButtint = False
logoButtint = False

playButton = ButtonClass('play_off.png',win_X/2-81,win_Y-133,162,66,'playButtint')
buttonsGr.add(playButton)
logoButton = ButtonClass('logo_off.png',win_X/2-306,33,612,132,None)
buttonsGr.add(logoButton)
buttonUpWorldSize = ButtonClass('buttonUp_off.png',win_X/10,win_Y/3,48,48,'world_sizeUp')
buttonsGr.add(buttonUpWorldSize)
buttonDownWorldSize = ButtonClass('buttonDown_off.png',win_X/10,win_Y/3+64,48,48,'world_sizeDown')
buttonsGr.add(buttonDownWorldSize)

#mixer.init()
#mixer.music.load('space.ogg')
#mixer.music.play(-1)
#fire = mixer.Sound('fire.ogg')

#player = Player('rocket.png', win_X/2, win_Y/2, 10, 50, 70)

font.init()
font1 = font.SysFont('Arial', 24)

courseour = GameSprite('courseour.png',0,0,0,1,1)

mousePic = transform.scale(image.load('mouse.png'),(16,16))
mouse_rect = mousePic.get_rect()

#FPS = 60
#clock = time.Clock()
#clock.tick(FPS)

game = True
gamestage = 'menu'
fullscreen_bool = False
mouse_down_bool = False
mouse_down_HELP = 0

while game:
    mouse_pos = mouse.get_pos()
    mouse.set_visible(False)
    keys_pressed = key.get_pressed()

    for i in event.get():
        if i.type == QUIT:
            game = False
        elif keys_pressed[K_F11]:
            fullscreen_bool = not fullscreen_bool
            if fullscreen_bool == True:
                window = display.set_mode((win_X,win_Y),FULLSCREEN)
            else:
                window = display.set_mode((win_X,win_Y))

        if i.type == MOUSEBUTTONDOWN and mouse_down_HELP == 0:
            mouse_down_bool = True
            mouse_down_HELP = 1
        else:
            mouse_down_bool = False
            if i.type == MOUSEBUTTONUP:
                mouse_down_HELP = 1

    window.blit(background,(0,0))
    
    if gamestage == 'game':
        roomsSprGr.draw(window)
        roomsSprGr.update(24)
    if gamestage == 'menu':
        buttonsGr.draw(window)
        buttonsGr.update()
        window.blit((font1.render('Граница мира: '+str(world_size)+'x'+str(world_size), False, (255, 255, 255))), (win_X/10-64,win_Y/3+128))
    if playButtint == True:
        gamestage = 'game'

    courseour.reset('courseour.png')
    window.blit(mousePic,(mouse_pos[0],mouse_pos[1]))
    display.update()

    
    
    
    

#collide_player = sprite.spritecollide(player, monsters, True)
#collide_enemy = sprite.groupcollide(monsters, bullets, True, True)
#window.blit(background,(0,0))
#scorebord = font1.render(str(seed), False, (255, 255, 255))
#window.blit(scorebord,(0,0))
#tik += 1
#elif i.type == KEYDOWN:
#    if i.key == K_UP and fnum == 0 and finish != True:
#        player.fire()
#        fnum = 1
#elif i.type == KEYUP:
#    if i.key in [K_UP]:
#        fnum = 0