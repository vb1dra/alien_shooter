from random import randint

def roomGenerator(help_integer):
    rooms = []
    seed = str(randint(0,1))
    for i in range(world_size**2-1):
        seed = seed+str(randint(0,1))
    b = 1
    for b in range(world_size+1):
        room = seed[world_size*(b-1) : world_size*b]
        rooms.append(room)
        print(rooms[b])

    b = 1
    while b <= world_size:

        for i in range(len(rooms[b])):
            RoomConHelp = 0
            if rooms[b][i] == '0':
                try:
                    if rooms[b][i-1] == '1' and i != 0: RoomConHelp += 1
                except: None
                try:
                    if rooms[b][i+1] == '1': RoomConHelp += 1
                except: None
                try:
                    if rooms[b-1][i] == '1': RoomConHelp += 1
                except:None
                try:
                    if rooms[b+1][i] == '1': RoomConHelp += 1
                except: None
                print(RoomConHelp)
                if RoomConHelp == 2 or RoomConHelp == 3:
                    c = str( rooms[b][0:i] ) + '2' + str(rooms[b][i+1:len(rooms[b])])
                    rooms[b] = c
        #print('\n'+rooms[b])
        b += 1

    for b in range(world_size+1):
        print(rooms[b])






world_size = int(input('Границы мира:'))
help_intgre = int(input('Кол-во комнат на экране:'))
roomGenerator(help_intgre)
#a = '1230456'
#b = a.find('0')
#print(a[0:b])
#print(a[b+1:len(a)])